import React from 'react';

const Header = () => {
  return (
    <header className="bg-white bg-opacity-30 backdrop-blur-lg p-4 shadow-md">
      <h1 className="text-xl font-bold">Dashboard</h1>
    </header>
  );
};

export default Header;