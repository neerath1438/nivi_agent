import React from 'react';

const Header = () => {
  return (
    <header className='bg-white bg-opacity-30 backdrop-blur-lg p-4 shadow-md'>
      <h1 className='text-xl font-bold'>App Logo</h1>
      <nav className='flex space-x-4'>
        <a href='#' className='text-gray-800'>Home</a>
        <a href='#' className='text-gray-800'>Dashboard</a>
      </nav>
    </header>
  );
};

export default Header;