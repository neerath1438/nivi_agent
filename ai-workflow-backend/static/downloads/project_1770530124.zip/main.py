{
  "files": [
    {
      "name": "main.py",
      "content": "from utils import get_user_input, add_numbers, display_result\n\n\ndef main():\n    num1, num2 = get_user_input()\n    result = add_numbers(num1, num2)\n    display_result(result)\n\n\nif __name__ == '__main__':\n    main()"
    },
    {
      "name": "utils.py",
      "content": "def get_user_input():\n    while True:\n        try:\n            num1 = float(input('Enter the first number: '))\n            num2 = float(input('Enter the second number: '))\n            return num1, num2\n        except ValueError:\n            print('Invalid input. Please enter numeric values.')\n\n\ndef add_numbers(num1, num2):\n    return num1 + num2\n\n\ndef display_result(result):\n    print(f'The sum of the two numbers is: {result}')"
    },
    {
      "name": "README.md",
      "content": "# Simple Addition Program\n\nThis is a simple Python program that performs the addition of two numbers.\n\n## How to Run\n1. Ensure you have Python installed.\n2. Run `main.py` to start the program.\n\n## Functions\n- `get_user_input()`: Prompts the user for two numbers and validates input.\n- `add_numbers(num1, num2)`: Adds two numbers and returns the result.\n- `display_result(result)`: Displays the result of the addition."
    }
  ]
}