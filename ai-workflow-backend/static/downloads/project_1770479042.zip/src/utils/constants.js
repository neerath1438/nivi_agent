export const API_ENDPOINTS = {
    PROPERTIES: '/api/properties',
};