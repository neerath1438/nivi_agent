import React, { useEffect, useState } from 'react';
import api from '../services/api';
import Button from '../components/ui/Button';

const Home = () => {
    const [properties, setProperties] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchProperties = async () => {
            try {
                const response = await api.get('/api/properties');
                setProperties(response.data);
            } catch (err) {
                setError(err);
                console.error('Error fetching properties:', err);
            }
        };
        fetchProperties();
    }, []);

    if (error) return <div>Error loading properties.</div>;

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            {properties.map(property => (
                <div key={property.id} className="border p-4 rounded shadow">
                    <h2 className="font-bold text-lg">{property.title}</h2>
                    <p>{property.description}</p>
                    <Button text="View Details" onClick={() => {}} />
                </div>
            ))}
        </div>
    );
};

export default Home;