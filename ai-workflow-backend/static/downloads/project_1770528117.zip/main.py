from fastapi import FastAPI, HTTPException, Depends
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import sessionmaker, DeclarativeBase, Mapped, mapped_column
from sqlalchemy.orm import Session
from pydantic import BaseModel
import os

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///:memory:")

# Database setup
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class Base(DeclarativeBase):
    pass

class BookModel(Base):
    __tablename__ = "books"
    
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    title: Mapped[str] = mapped_column(String, index=True)
    author: Mapped[str] = mapped_column(String)
    published_date: Mapped[str] = mapped_column(String)
    isbn: Mapped[str] = mapped_column(String)

Base.metadata.create_all(bind=engine)

# Pydantic schemas
class BookBase(BaseModel):
    title: str
    author: str
    published_date: str
    isbn: str

class BookCreate(BookBase):
    pass

class Book(BookBase):
    id: int

    class Config:
        from_attributes = True

# CRUD operations
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_book(db: Session, book_id: int):
    return db.query(BookModel).filter(BookModel.id == book_id).first()

def create_book(db: Session, book: BookCreate):
    db_book = BookModel(**book.model_dump())
    db.add(db_book)
    db.commit()
    db.refresh(db_book)
    return db_book

# FastAPI app
app = FastAPI()

@app.post("/books/", response_model=Book)
def api_create_book(book: BookCreate, db: Session = Depends(get_db)):
    return create_book(db=db, book=book)

@app.get("/books/{book_id}", response_model=Book)
def api_get_book(book_id: int, db: Session = Depends(get_db)):
    db_book = get_book(db=db, book_id=book_id)
    if db_book is None:
        raise HTTPException(status_code=404, detail="Book not found")
    return db_book

# Testing
client = TestClient(app)

def test_create_book():
    response = client.post("/books/", json={"title": "Test Book", "author": "Author", "published_date": "2023-01-01", "isbn": "1234567890"})
    print(response.json())
    assert response.status_code == 200

def test_get_book():
    response = client.get("/books/1")
    print(response.json())
    assert response.status_code == 200

test_create_book()
test_get_book()