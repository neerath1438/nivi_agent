module.exports = {
  purge: ['./index.html', './src*.{js,jsx,ts,tsx}', './public/index.html'],
  darkMode: false,
  theme: {
    extend: {}
  },
  variants: {},
  plugins: []
};