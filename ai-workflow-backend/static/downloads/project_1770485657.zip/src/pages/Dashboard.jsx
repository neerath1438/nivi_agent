import React from 'react';
import Sidebar from '../components/common/Sidebar';
import StatsCard from '../components/ui/StatsCard';
import DataTable from '../components/ui/DataTable';

const Dashboard = () => {
  return (
    <div className="flex">
      <Sidebar />
      <main className="flex-1 p-4">
        <StatsCard />
        <DataTable />
      </main>
    </div>
  );
};

export default Dashboard;