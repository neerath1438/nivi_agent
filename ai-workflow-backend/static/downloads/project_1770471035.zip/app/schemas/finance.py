from pydantic import BaseModel
from datetime import datetime

class IncomeSchema(BaseModel):
    amount: float
    source: str
    date: datetime

class ExpenseSchema(BaseModel):
    amount: float
    category: str
    date: datetime

class BudgetSchema(BaseModel):
    category: str
    limit: float
    month: datetime
