import React from 'react';

const StatCard = ({ title, value }) => {
  return (
    <div className="bg-white bg-opacity-30 backdrop-blur-lg shadow-xl p-4 rounded-lg text-center">
      <h2 className="text-lg font-semibold text-white">{title}</h2>
      <p className="text-2xl text-gray-300">{value}</p>
    </div>
  );
};

export default StatCard;