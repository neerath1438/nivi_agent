import React from 'react';

const Input = ({ value, placeholder, onChange, type }) => {
    return (
        <input type={type} value={value} onChange={onChange} placeholder={placeholder} className="border rounded p-2 focus:outline-none focus:ring-2 focus:ring-blue-600" />
    );
};

export default Input;