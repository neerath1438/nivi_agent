import { useState, useEffect } from 'react';

const useAuth = () => {
    const [user, setUser] = useState(null);

    useEffect(() => {
        // Logic to check authentication
    }, []);

    return { user, setUser };
};

export default useAuth;