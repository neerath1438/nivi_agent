import React from 'react';

const Input = ({ type, placeholder, onChange }) => {
  return (
    <input
      type={type}
      placeholder={placeholder}
      onChange={onChange}
      className="border rounded p-2 focus:outline-none focus:ring-2 focus:ring-primary"
    />
  );
};

export default Input;