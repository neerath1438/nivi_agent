import React from 'react';
import Dashboard from './components/Dashboard';

const App = () => {
  return (
    <div className="bg-gradient-to-r from-blue-500 to-purple-500 min-h-screen flex flex-col">
      <Dashboard />
    </div>
  );
};

export default App;