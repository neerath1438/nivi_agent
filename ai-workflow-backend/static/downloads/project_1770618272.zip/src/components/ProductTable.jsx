import React from 'react';

const ProductTable = ({ products }) => {
  return (
    <table className="min-w-full bg-white bg-opacity-30 backdrop-blur-lg shadow-xl rounded-lg">
      <thead>
        <tr className="bg-primary text-white">
          <th className="py-2">Asset</th>
          <th className="py-2">Value</th>
          <th className="py-2">Change</th>
        </tr>
      </thead>
      <tbody>
        {products.map((product, index) => (
          <tr key={index} className="hover:bg-gray-200 transition-all">
            <td className="py-2">{product.name}</td>
            <td className="py-2">${product.value}</td>
            <td className="py-2">{product.change}%</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default ProductTable;