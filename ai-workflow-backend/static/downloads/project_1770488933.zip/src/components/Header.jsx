import React from 'react';

const Header = () => {
  return (
    <header className="bg-white bg-opacity-30 backdrop-blur-lg rounded-lg shadow-lg p-4 mb-4">
      <h1 className="text-2xl font-bold">Dashboard Header</h1>
    </header>
  );
};

export default Header;