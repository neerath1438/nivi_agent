import React from 'react';

const DataTable = () => {
  return (
    <div className="bg-white bg-opacity-30 backdrop-blur-lg p-4 rounded-lg shadow-lg mt-4">
      <h3 className="text-lg font-bold">User Data</h3>
      <table className="min-w-full mt-2">
        <thead>
          <tr>
            <th className="border-b-2 border-gray-300 px-4 py-2">Name</th>
            <th className="border-b-2 border-gray-300 px-4 py-2">Email</th>
            <th className="border-b-2 border-gray-300 px-4 py-2">Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className="border-b border-gray-200 px-4 py-2">John Doe</td>
            <td className="border-b border-gray-200 px-4 py-2">john@example.com</td>
            <td className="border-b border-gray-200 px-4 py-2">Active</td>
          </tr>
          <tr>
            <td className="border-b border-gray-200 px-4 py-2">Jane Smith</td>
            <td className="border-b border-gray-200 px-4 py-2">jane@example.com</td>
            <td className="border-b border-gray-200 px-4 py-2">Inactive</td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;