from sqlalchemy import Column, String, Float
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Product(Base):
    __tablename__ = 'products'
    name = Column(String, nullable=False)
    sku = Column(String, primary_key=True)
    price = Column(Float, nullable=False)

mock_products = [
    Product(name='Sample Product 1', sku='SKU001', price=19.99),
    Product(name='Sample Product 2', sku='SKU002', price=29.99)
]