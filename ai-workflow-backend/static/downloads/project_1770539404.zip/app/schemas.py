from pydantic import BaseModel
from typing import Optional

class BookBase(BaseModel):
    title: str
    author: str
    price: int
    published_date: str

class BookCreate(BookBase):
    pass

class BookUpdate(BookBase):
    title: Optional[str] = None
    author: Optional[str] = None
    price: Optional[int] = None
    published_date: Optional[str] = None

class Book(BookBase):
    id: int

    class Config:
        orm_mode = True