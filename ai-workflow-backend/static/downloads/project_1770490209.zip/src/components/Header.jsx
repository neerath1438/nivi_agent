import React from 'react';

const Header = () => {
  return (
    <div className="bg-white bg-opacity-30 backdrop-blur-lg p-4">
      <h1 className="text-2xl font-bold">User Dashboard</h1>
      <button className="float-right bg-blue-500 text-white px-4 py-2 rounded">Logout</button>
    </div>
  );
};

export default Header;