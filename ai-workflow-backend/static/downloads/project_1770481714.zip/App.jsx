[
  {
    "path": "package.json",
    "content": "{\n  \"name\": \"real-estate-portal\",\n  \"version\": \"1.0.0\",\n  \"scripts\": {\n    \"dev\": \"vite\",\n    \"build\": \"vite build\",\n    \"serve\": \"vite preview\"\n  },\n  \"dependencies\": {\n    \"react\": \"^18.2.0\",\n    \"react-dom\": \"^18.2.0\",\n    \"react-router-dom\": \"^6.14.0\",\n    \"axios\": \"^1.4.0\",\n    \"lucide-react\": \"^0.30.0\"\n  },\n  \"devDependencies\": {\n    \"vite\": \"^5.0.0\",\n    \"@vitejs/plugin-react\": \"^4.2.0\",\n    \"tailwindcss\": \"^3.0.0\"\n  }\n}"
  },
  {
    "path": "vite.config.js",
    "content": "import { defineConfig } from 'vite';\nimport react from '@vitejs/plugin-react';\n\nexport default defineConfig({\n  plugins: [react()],\n  server: {\n    port: 3000\n  }\n});"
  },
  {
    "path": "tailwind.config.js",
    "content": "module.exports = {\n  content: ['./index.html', './src*.{js,jsx,ts,tsx}'],\n  theme: {\n    extend: {},\n  },\n  plugins: [],\n};"
  },
  {
    "path": "index.html",
    "content": "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n    <meta charset=\"UTF-8\">\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n    <link href=\"https:
  },
  {
    "path": "src/main.jsx",
    "content": "import React from 'react';\nimport ReactDOM from 'react-dom';\nimport App from './App';\nimport './index.css';\n\nReactDOM.render(<App />, document.getElementById('app'));"
  },
  {
    "path": "src/App.jsx",
    "content": "import React from 'react';\nimport MainLayout from './layouts/MainLayout';\nimport Home from './pages/Home';\n\nconst App = () => {\n  return (\n    <MainLayout>\n      <Home />\n    </MainLayout>\n  );\n};\n\nexport default App;"
  },
  {
    "path": "src/layouts/MainLayout.jsx",
    "content": "import React from 'react';\nimport Navbar from '../common/Navbar';\nimport Footer from '../common/Footer';\n\nconst MainLayout = ({ children }) => {\n  return (\n    <div className=\"flex flex-col min-h-screen\">\n      <Navbar />\n      <main className=\"flex-grow\">{children}</main>\n      <Footer />\n    </div>\n  );\n};\n\nexport default MainLayout;"
  },
  {
    "path": "src/pages/Home.jsx",
    "content": "import React, { useEffect, useState } from 'react';\nimport { fetchProperties } from '../api/api';\n\nconst Home = () => {\n  const [properties, setProperties] = useState([]);\n  const [loading, setLoading] = useState(true);\n\n  useEffect(() => {\n    const loadProperties = async () => {\n      try {\n        const data = await fetchProperties();\n        setProperties(data);\n      } catch (error) {\n        console.error(error);\n      } finally {\n        setLoading(false);\n      }\n    };\n    loadProperties();\n  }, []);\n\n  if (loading) return <div>Loading...</div>;\n\n  return (\n    <div className=\"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4\">\n      {properties.map(property => (\n        <div key={property.id} className=\"border rounded-lg p-4\">\n          <img src={property.image} alt={property.title} className=\"w-full h-48 object-cover rounded\" />\n          <h2 className=\"font-bold text-lg mt-2\">{property.title}</h2>\n          <p className=\"text-gray-600\">{property.description}</p>\n        </div>\n      ))}\n    </div>\n  );\n};\n\nexport default Home;"
  },
  {
    "path": "src/common/Navbar.jsx",
    "content": "import React from 'react';\nimport { Link } from 'react-router-dom';\n\nconst Navbar = () => {\n  return (\n    <nav className=\"bg-blue-500 p-4\">\n      <ul className=\"flex space-x-4\">\n        <li><Link to=\"/\" className=\"text-white\">Home</Link></li>\n        <li><Link to=\"/about\" className=\"text-white\">About</Link></li>\n        <li><Link to=\"/contact\" className=\"text-white\">Contact</Link></li>\n      </ul>\n    </nav>\n  );\n};\n\nexport default Navbar;"
  },
  {
    "path": "src/common/Footer.jsx",
    "content": "import React from 'react';\n\nconst Footer = () => {\n  return (\n    <footer className=\"bg-gray-800 text-white p-4 text-center\">\n      <p>Contact us: info@example.com</p>\n      <p>Follow us on social media</p>\n      <p>&copy; 2023 Real Estate Portal</p>\n    </footer>\n  );\n};\n\nexport default Footer;"
  },
  {
    "path": "src/components/Button.jsx",
    "content": "import React from 'react';\n\nconst Button = ({ label, onClick, type = 'button', className }) => {\n  return (\n    <button\n      type={type}\n      onClick={onClick}\n      className={`bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 active:bg-blue-700 ${className}`}\n    >\n      {label}\n    </button>\n  );\n};\n\nexport default Button;"
  },
  {
    "path": "src/components/Input.jsx",
    "content": "import React from 'react';\n\nconst Input = ({ placeholder, value, onChange, type = 'text', className }) => {\n  return (\n    <input\n      type={type}\n      value={value}\n      onChange={onChange}\n      placeholder={placeholder}\n      className={`border rounded p-2 ${className}`}\n    />\n  );\n};\n\nexport default Input;"
  },
  {
    "path": "src/api/api.js",
    "content": "export const fetchProperties = async () => {\n  try {\n    const response = await fetch('https:
  },
  {
    "path": "src/index.css",
    "content": "@tailwind base;\n@tailwind components;\n@tailwind utilities;"
  }
]