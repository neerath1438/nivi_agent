import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white bg-opacity-30 backdrop-blur-lg p-4 shadow-md text-center">
      <p>&copy; 2023 Your Company. All rights reserved.</p>
    </footer>
  );
};

export default Footer;