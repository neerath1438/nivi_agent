import React from 'react';

export const Timeline = ({ events }) => {
  return (
    <div className="bg-white bg-opacity-30 backdrop-blur-lg shadow-lg p-4 rounded-lg">
      <h3 className="font-semibold">Order Status Timeline</h3>
      <ul>
        {events.map((event) => (
          <li key={event.id} className="flex items-center">
            <span className="mr-2">{event.date}</span>
            <span>{event.status}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};