import React from 'react';

const Navbar = () => {
  return (
    <nav className='fixed top-0 left-0 w-full bg-white shadow-md p-4'>
      <div className='flex justify-between'>
        <div className='font-bold'>Logo</div>
        <div className='space-x-4'>
          <a href='/'>Home</a>
          <a href='/listings'>Property Listings</a>
          <a href='/contact'>Contact</a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;