import React from 'react';

const Sidebar = () => {
  return (
    <div className="w-64 bg-white bg-opacity-30 backdrop-blur-lg p-4">
      <h2 className="text-xl font-bold">Dashboard</h2>
      <ul className="mt-4">
        <li className="py-2 hover:bg-gray-200 rounded">Overview</li>
        <li className="py-2 hover:bg-gray-200 rounded">Reports</li>
        <li className="py-2 hover:bg-gray-200 rounded">Settings</li>
      </ul>
    </div>
  );
};

export default Sidebar;