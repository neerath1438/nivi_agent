from fastapi import FastAPI
from app.database.connection import engine
from app.routes.finance import router as finance_router

app = FastAPI()

# Include the finance router
app.include_router(finance_router)

@app.on_event("startup")
async def startup():
    # Create the database tables
    import app.models.finance as models
    models.Base.metadata.create_all(bind=engine)

@app.get("/")
def read_root():
    return {"message": "Welcome to the Personal Finance Tracker API"}
