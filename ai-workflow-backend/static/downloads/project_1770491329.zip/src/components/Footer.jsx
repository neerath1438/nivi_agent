import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white shadow-lg p-4 text-center">
      <p>&copy; 2023 Your Company. All rights reserved.</p>
      <p><a href="#">Terms of Service</a> | <a href="#">Privacy Policy</a></p>
    </footer>
  );
};

export default Footer;