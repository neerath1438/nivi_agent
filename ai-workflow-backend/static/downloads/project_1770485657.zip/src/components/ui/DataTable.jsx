import React from 'react';

const DataTable = () => {
  return (
    <table className="min-w-full">
      <thead>
        <tr className="bg-gray-200">
          <th>User ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Revenue</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        {}
      </tbody>
    </table>
  );
};

export default DataTable;