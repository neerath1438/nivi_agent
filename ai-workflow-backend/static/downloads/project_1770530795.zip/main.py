{
  "files": [
    {
      "name": "main.py",
      "content": "import json\nimport os\nfrom datetime import datetime\nfrom arithmetic import add, subtract, multiply, divide\n\ndef log_operation(operation, input1, input2, result):\n    log_entry = {\n        'operation': operation,\n        'input1': input1,\n        'input2': input2,\n        'result': result,\n        'timestamp': datetime.now().isoformat()\n    }\n    log_file_path = 'data/operations_log.json'\n    if not os.path.exists('data'):\n        os.makedirs('data')\n    if os.path.exists(log_file_path):\n        with open(log_file_path, 'r') as log_file:\n            logs = json.load(log_file)\n    else:\n        logs = []\n    logs.append(log_entry)\n    with open(log_file_path, 'w') as log_file:\n        json.dump(logs, log_file, indent=4)\n\nif __name__ == '__main__':\n    try:\n        num1 = float(input('Enter first number: '))\n        num2 = float(input('Enter second number: '))\n        operation = input('Select operation (add, subtract, multiply, divide): ').strip().lower()\n\n        if operation == 'add':\n            result = add(num1, num2)\n            print(f'Result: {result}')\n            log_operation('add', num1, num2, result)\n        elif operation == 'subtract':\n            result = subtract(num1, num2)\n            print(f'Result: {result}')\n            log_operation('subtract', num1, num2, result)\n        elif operation == 'multiply':\n            result = multiply(num1, num2)\n            print(f'Result: {result}')\n            log_operation('multiply', num1, num2, result)\n        elif operation == 'divide':\n            result = divide(num1, num2)\n            print(f'Result: {result}')\n            log_operation('divide', num1, num2, result)\n        else:\n            print('Invalid operation selected.')\n    except ValueError:\n        print('Invalid input. Please enter numeric values.')\n    except Exception as e:\n        print(f'An error occurred: {e}')"
    },
    {
      "name": "arithmetic.py",
      "content": "def add(a, b):\n    return a + b\n\ndef subtract(a, b):\n    return a - b\n\ndef multiply(a, b):\n    return a * b\n\ndef divide(a, b):\n    if b == 0:\n        raise ValueError('Cannot divide by zero.')\n    return a / b"
    },
    {
      "name": "test_arithmetic.py",
      "content": "import unittest\nfrom arithmetic import add, subtract, multiply, divide\n\nclass TestArithmetic(unittest.TestCase):\n    def test_add(self):\n        self.assertEqual(add(1, 2), 3)\n        self.assertEqual(add(-1, 1), 0)\n\n    def test_subtract(self):\n        self.assertEqual(subtract(5, 3), 2)\n        self.assertEqual(subtract(0, 1), -1)\n\n    def test_multiply(self):\n        self.assertEqual(multiply(3, 4), 12)\n        self.assertEqual(multiply(-1, 1), -1)\n\n    def test_divide(self):\n        self.assertEqual(divide(10, 2), 5)\n        with self.assertRaises(ValueError):\n            divide(10, 0)\n\n    def test_invalid_input(self):\n        with self.assertRaises(TypeError):\n            add('a', 1)\n        with self.assertRaises(TypeError):\n            subtract(1, 'b')\n\nif __name__ == '__main__':\n    unittest.main()"
    },
    {
      "name": "requirements.txt",
      "content": "json"
    }
  ]
}