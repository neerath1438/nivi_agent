import React from 'react';
import { Sidebar } from './components/ui/Sidebar';
import { Dashboard } from './pages/Dashboard';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-r from-blue-500 to-purple-500 flex">
      <Sidebar />
      <main className="flex-1 p-6">
        <Dashboard />
      </main>
    </div>
  );
}

export default App;