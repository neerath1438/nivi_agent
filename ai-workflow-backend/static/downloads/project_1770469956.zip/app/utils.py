# Utility functions can be added here
