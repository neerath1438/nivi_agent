from sqlalchemy import Column, Float, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Income(Base):
    __tablename__ = 'income'
    id = Column(Integer, primary_key=True, index=True)
    amount = Column(Float)
    source = Column(String)
    date = Column(DateTime)

class Expense(Base):
    __tablename__ = 'expenses'
    id = Column(Integer, primary_key=True, index=True)
    amount = Column(Float)
    category = Column(String)
    date = Column(DateTime)

class Budget(Base):
    __tablename__ = 'budget'
    id = Column(Integer, primary_key=True, index=True)
    category = Column(String)
    limit = Column(Float)
    month = Column(DateTime)
