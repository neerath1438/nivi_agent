import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

@pytest.fixture
def test_client():
    yield client

def test_create_book(test_client):
    response = test_client.post("/books/", json={"title": "Test Book", "author": "Author", "description": "A test book", "price": 10})
    assert response.status_code == 200
    assert response.json()["title"] == "Test Book"

def test_read_book(test_client):
    response = test_client.get("/books/1")
    assert response.status_code == 404

# Additional tests for update and delete can be added here.