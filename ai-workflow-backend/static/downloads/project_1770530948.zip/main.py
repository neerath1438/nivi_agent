import logging

# Configure logging
logging.basicConfig(filename='arithmetic_operations.log', level=logging.INFO, format='%(asctime)s - %(message)s')

def add(x, y):
    return x + y

def subtract(x, y):
    return x - y

def multiply(x, y):
    return x * y

def divide(x, y):
    if y == 0:
        raise ValueError("Cannot divide by zero.")
    return x / y

def log_operation(operation, x, y, result):
    logging.info(f"Operation: {operation}, x: {x}, y: {y}, Result: {result}")

def main():
    while True:
        print("Select an operation:")
        print("1. Add")
        print("2. Subtract")
        print("3. Multiply")
        print("4. Divide")
        print("5. Exit")

        choice = input("Enter choice (1/2/3/4/5): ")

        if choice == '5':
            print("Exiting the program.")
            break

        if choice in ['1', '2', '3', '4']:
            try:
                x = float(input("Enter first number: "))
                y = float(input("Enter second number: "))
            except ValueError:
                print("Invalid input. Please enter numeric values.")
                continue

            try:
                if choice == '1':
                    result = add(x, y)
                    operation = "Addition"
                elif choice == '2':
                    result = subtract(x, y)
                    operation = "Subtraction"
                elif choice == '3':
                    result = multiply(x, y)
                    operation = "Multiplication"
                elif choice == '4':
                    result = divide(x, y)
                    operation = "Division"

                print(f"The result is: {result}")
                log_operation(operation, x, y, result)

            except ValueError as e:
                print(e)

if __name__ == "__main__":
    try:
        main()
    except EOFError:
        print("Input was interrupted. Exiting the program.")