from sqlalchemy.ext.asyncio import AsyncSession
from app.models.user import User
from app.repositories.user_repo import get_user_by_username, create_user as repo_create_user
from app.core.security import get_password_hash

async def create_user(user_data, db: AsyncSession):
    existing_user = await get_user_by_username(db, user_data.username)
    if existing_user:
        return None
    user = User(username=user_data.username, email=user_data.email, hashed_password=get_password_hash(user_data.password))
    return await repo_create_user(db, user)

async def authenticate_user(username: str, password: str, db: AsyncSession):
    user = await get_user_by_username(db, username)
    if user and verify_password(password, user.hashed_password):
        return user
    return None

async def get_user(user_id: int, db: AsyncSession):
    return await get_user(db, user_id)

async def delete_user(user_id: int, db: AsyncSession):
    return await delete_user(user_id, db)
