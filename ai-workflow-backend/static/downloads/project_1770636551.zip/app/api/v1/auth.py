from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.schemas.user import UserCreate, UserResponse
from app.services.user_service import create_user, authenticate_user
from app.core.security import create_access_token

router = APIRouter()

@router.post('/register', response_model=UserResponse)
async def register(user: UserCreate, db: AsyncSession = Depends(get_db)):
    existing_user = await create_user(user, db)
    if existing_user:
        raise HTTPException(status_code=400, detail='Username already exists.')
    return existing_user

@router.post('/login')
async def login(user: UserCreate, db: AsyncSession = Depends(get_db)):
    user = await authenticate_user(user.username, user.password, db)
    if not user:
        raise HTTPException(status_code=401, detail='Invalid username or password.')
    access_token = create_access_token(data={'sub': user.username})
    return {'access_token': access_token, 'token_type': 'bearer'}
