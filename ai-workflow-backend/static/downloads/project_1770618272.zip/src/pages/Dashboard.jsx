import React from 'react';
import Sidebar from '../components/Sidebar';
import Navbar from '../components/Navbar';
import HeroSection from '../components/HeroSection';
import StatCard from '../components/StatCard';
import AnalyticsChart from '../components/AnalyticsChart';
import ProductTable from '../components/ProductTable';

const mockData = [
  { name: 'Bitcoin', value: 5000, change: 2 },
  { name: 'Ethereum', value: 3000, change: -1 },
];

const Dashboard = () => {
  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1 p-6">
        <Navbar />
        <HeroSection />
        <div className="grid grid-cols-3 gap-4 mt-4">
          <StatCard title="Total Assets" value="5" />
          <StatCard title="Daily Gain/Loss" value="+2%" />
          <StatCard title="Market Trends" value="Stable" />
        </div>
        <AnalyticsChart data={[{ name: 'Jan', value: 4000 }, { name: 'Feb', value: 3000 }]} />
        <ProductTable products={mockData} />
      </div>
    </div>
  );
};

export default Dashboard;