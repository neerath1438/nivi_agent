import React from 'react';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';

const Login = () => {
    return (
        <div className="flex items-center justify-center h-screen">
            <div className="bg-white p-6 rounded-lg shadow-md w-96">
                <h2 className="text-xl font-bold mb-4">Login</h2>
                <Input placeholder="Email" type="email" />
                <Input placeholder="Password" type="password" className="mt-4" />
                <Button label="Login" onClick={() => {}} className="mt-4" />
            </div>
        </div>
    );
};

export default Login;