import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

@pytest.fixture
def create_user():
    response = client.post("/users/", json={"username": "testuser", "email": "test@example.com", "password": "testpass"})
    return response.json()

def test_create_user(create_user):
    assert create_user['username'] == "testuser"

def test_read_user(create_user):
    response = client.get(f"/users/{create_user['id']}")
    assert response.status_code == 200
    assert response.json()['username'] == "testuser"

def test_update_user(create_user):
    response = client.put(f"/users/{create_user['id']}", json={"username": "updateduser"})
    assert response.status_code == 200
    assert response.json()['username'] == "updateduser"

def test_delete_user(create_user):
    response = client.delete(f"/users/{create_user['id']}")
    assert response.status_code == 204
    response = client.get(f"/users/{create_user['id']}")
    assert response.status_code == 404
