from fastapi import FastAPI
from app.routers import users
from app.database import engine, Base

# Create the database tables
Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(users.router, prefix='/users', tags=['users'])
