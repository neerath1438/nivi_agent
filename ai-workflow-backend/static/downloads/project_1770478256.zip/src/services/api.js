const API_URL = 'https://api.example.com/properties';

export const fetchProperties = async () => {
    try {
        const response = await fetch(API_URL);
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.json();
    } catch (error) {
        console.error('Fetch properties error:', error);
        return [];
    }
};

export const fetchPropertyById = async (id) => {
    try {
        const response = await fetch(`${API_URL}/${id}`);
        if (!response.ok) throw new Error('Network response was not ok');
        return await response.json();
    } catch (error) {
        console.error('Fetch property by ID error:', error);
        return null;
    }
};

export default { fetchProperties, fetchPropertyById };