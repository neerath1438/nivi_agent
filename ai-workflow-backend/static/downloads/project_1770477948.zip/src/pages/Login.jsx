import React from 'react';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';

const Login = () => {
    return (
        <div className="container mx-auto p-4">
            <h1 className="text-2xl font-bold mb-4">Login</h1>
            <form>
                <Input type="text" placeholder="Username" className="mb-4" />
                <Input type="password" placeholder="Password" className="mb-4" />
                <Button type="submit">Login</Button>
            </form>
        </div>
    );
};

export default Login;