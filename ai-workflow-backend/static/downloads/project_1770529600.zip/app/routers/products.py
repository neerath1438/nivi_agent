from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from app.models.database import Product, mock_products

router = APIRouter()

class ProductCreate(BaseModel):
    name: str
    sku: str
    price: float

class ProductResponse(BaseModel):
    name: str
    sku: str
    price: float

@router.get('/products', response_model=List[ProductResponse])
async def get_products():
    return mock_products

@router.get('/products/{sku}', response_model=ProductResponse)
async def get_product(sku: str):
    product = next((p for p in mock_products if p.sku == sku), None)
    if product is None:
        raise HTTPException(status_code=404, detail='Product not found')
    return product

@router.post('/products', response_model=ProductResponse)
async def create_product(product: ProductCreate):
    new_product = Product(name=product.name, sku=product.sku, price=product.price)
    mock_products.append(new_product)
    return new_product

@router.put('/products/{sku}', response_model=ProductResponse)
async def update_product(sku: str, product: ProductCreate):
    existing_product = next((p for p in mock_products if p.sku == sku), None)
    if existing_product is None:
        raise HTTPException(status_code=404, detail='Product not found')
    existing_product.name = product.name
    existing_product.price = product.price
    return existing_product

@router.delete('/products/{sku}', response_model=ProductResponse)
async def delete_product(sku: str):
    global mock_products
    mock_products = [p for p in mock_products if p.sku != sku]
    return {'detail': 'Product deleted'}