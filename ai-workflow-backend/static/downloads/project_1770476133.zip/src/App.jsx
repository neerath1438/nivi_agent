import React from 'react';
import './index.css';

const App = () => {
  return (
    <div className="bg-gradient-to-br from-white/10 to-black/10 min-h-screen text-white">
      <header className="flex justify-between p-5 backdrop-blur-lg">
        <div className="text-2xl font-bold">AI Startup</div>
        <nav>
          <ul className="flex gap-5 list-none">
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </nav>
      </header>
      <main>
        <section id="home" className="text-center py-24 backdrop-blur-lg">
          <h1 className="text-4xl font-bold">Welcome to the Future of AI</h1>
          <p className="mt-4 text-lg">Innovating with cutting-edge technology.</p>
          <button className="mt-6 px-4 py-2 bg-white text-black rounded-lg">Get Started</button>
        </section>
        <section id="about" className="py-24">
          <h2 className="text-3xl font-bold text-center">About Us</h2>
          <div className="flex justify-center mt-10">
            {['Feature 1', 'Feature 2', 'Feature 3'].map((feature, index) => (
              <div key={index} className="bg-white/20 rounded-lg p-5 m-2 backdrop-blur-lg">
                {feature}
              </div>
            ))}
          </div>
        </section>
        <section id="testimonials" className="py-24">
          <h2 className="text-3xl font-bold text-center">What Our Clients Say</h2>
          <div className="mt-10" id="testimonial-slider">{/* Slider Component */}</div>
        </section>
      </main>
      <footer className="text-center p-5 backdrop-blur-lg">
        <p>Follow us on social media!</p>
        <p>© 2023 AI Startup. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;