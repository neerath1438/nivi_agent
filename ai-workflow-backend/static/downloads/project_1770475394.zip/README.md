# AI StartUp Landing Page

This project is a modern landing page for an AI startup showcasing services and facilitating user engagement.

## Tech Stack
- HTML5
- CSS3
- Vanilla JS

## Features
- Glassmorphism design
- Responsive layout
- Smooth scrolling navigation
- Testimonials carousel
- Subscription form with validation

## Installation
1. Clone the repository.
2. Open `index.html` in your browser.

## Assets
- Images folder for service images.
- Link to Google Fonts for typography.
