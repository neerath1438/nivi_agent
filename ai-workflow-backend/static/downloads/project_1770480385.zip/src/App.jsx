import React from 'react';
import MainLayout from './components/common/MainLayout.jsx';
import Home from './pages/Home.jsx';

const App = () => {
  return (
    <MainLayout>
      <Home />
    </MainLayout>
  );
};

export default App;