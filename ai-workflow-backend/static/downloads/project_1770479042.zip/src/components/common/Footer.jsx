import React from 'react';

const Footer = () => {
    return (
        <footer className="fixed bottom-0 w-full bg-gray-200 text-center p-4">
            <p>&copy; 2023 Real Estate Portal. All rights reserved.</p>
        </footer>
    );
};

export default Footer;