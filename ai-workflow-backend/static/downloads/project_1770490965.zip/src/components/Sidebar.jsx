import React from 'react';

const Sidebar = () => {
  return (
    <aside className="bg-white bg-opacity-30 backdrop-blur-lg w-64 p-4 shadow-md">
      <nav>
        <ul>
          <li>Home</li>
          <li>Settings</li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;