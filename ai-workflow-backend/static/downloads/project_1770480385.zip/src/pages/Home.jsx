import React from 'react';
import { fetchProperties } from '../api';

const Home = () => {
  const [properties, setProperties] = React.useState([]);

  React.useEffect(() => {
    const getProperties = async () => {
      const data = await fetchProperties();
      setProperties(data);
    };
    getProperties();
  }, []);

  return (
    <div>
      <h1>Properties</h1>
      <ul>
        {properties.map(property => (
          <li key={property.id}>{property.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default Home;