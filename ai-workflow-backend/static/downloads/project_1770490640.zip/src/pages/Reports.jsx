import React from 'react';

const Reports = () => {
  return (
    <div>
      <h2 className="text-2xl font-semibold">Reports Page</h2>
    </div>
  );
};

export default Reports;