import React from 'react';

const PropertyCard = ({ property }) => {
  return (
    <div className="border rounded shadow p-4">
      <h2 className="font-bold text-xl">{property.title}</h2>
      <p>{property.description}</p>
      <p className="text-gray-600">${property.price}</p>
    </div>
  );
};

export default PropertyCard;