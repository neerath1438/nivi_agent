from app.models.finance import Income, Expense, Budget
from app.database.connection import SessionLocal

class IncomeService:
    @staticmethod
    def create(income_data):
        db = SessionLocal()
        income = Income(**income_data.dict())
        db.add(income)
        db.commit()
        db.refresh(income)
        db.close()
        return income

    @staticmethod
    def retrieve():
        db = SessionLocal()
        incomes = db.query(Income).all()
        db.close()
        return incomes

    @staticmethod
    def update(id, income_data):
        db = SessionLocal()
        income = db.query(Income).filter(Income.id == id).first()
        if not income:
            db.close()
            raise HTTPException(status_code=404, detail="Income not found")
        for key, value in income_data.dict().items():
            setattr(income, key, value)
        db.commit()
        db.refresh(income)
        db.close()
        return income

    @staticmethod
    def delete(id):
        db = SessionLocal()
        income = db.query(Income).filter(Income.id == id).first()
        if not income:
            db.close()
            raise HTTPException(status_code=404, detail="Income not found")
        db.delete(income)
        db.commit()
        db.close()
        return {"detail": "Income deleted"}

class ExpenseService:
    @staticmethod
    def create(expense_data):
        db = SessionLocal()
        expense = Expense(**expense_data.dict())
        db.add(expense)
        db.commit()
        db.refresh(expense)
        db.close()
        return expense

    @staticmethod
    def retrieve():
        db = SessionLocal()
        expenses = db.query(Expense).all()
        db.close()
        return expenses

    @staticmethod
    def update(id, expense_data):
        db = SessionLocal()
        expense = db.query(Expense).filter(Expense.id == id).first()
        if not expense:
            db.close()
            raise HTTPException(status_code=404, detail="Expense not found")
        for key, value in expense_data.dict().items():
            setattr(expense, key, value)
        db.commit()
        db.refresh(expense)
        db.close()
        return expense

    @staticmethod
    def delete(id):
        db = SessionLocal()
        expense = db.query(Expense).filter(Expense.id == id).first()
        if not expense:
            db.close()
            raise HTTPException(status_code=404, detail="Expense not found")
        db.delete(expense)
        db.commit()
        db.close()
        return {"detail": "Expense deleted"}

class BudgetService:
    @staticmethod
    def create(budget_data):
        db = SessionLocal()
        budget = Budget(**budget_data.dict())
        db.add(budget)
        db.commit()
        db.refresh(budget)
        db.close()
        return budget

    @staticmethod
    def retrieve():
        db = SessionLocal()
        budgets = db.query(Budget).all()
        db.close()
        return budgets

    @staticmethod
    def update(id, budget_data):
        db = SessionLocal()
        budget = db.query(Budget).filter(Budget.id == id).first()
        if not budget:
            db.close()
            raise HTTPException(status_code=404, detail="Budget not found")
        for key, value in budget_data.dict().items():
            setattr(budget, key, value)
        db.commit()
        db.refresh(budget)
        db.close()
        return budget

    @staticmethod
    def delete(id):
        db = SessionLocal()
        budget = db.query(Budget).filter(Budget.id == id).first()
        if not budget:
            db.close()
            raise HTTPException(status_code=404, detail="Budget not found")
        db.delete(budget)
        db.commit()
        db.close()
        return {"detail": "Budget deleted"}
