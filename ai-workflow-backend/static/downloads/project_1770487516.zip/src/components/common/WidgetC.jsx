import React from 'react';

const WidgetC = () => {
  return (
    <div className='bg-white p-4 shadow-lg rounded-lg'>
      <h2>Recent Activities</h2>
      <p>List of recent activities goes here.</p>
    </div>
  );
};

export default WidgetC;