# Library API

## Setup

1. Install dependencies: `pip install -r requirements.txt`
2. Run the application: `uvicorn app.main:app --reload`

## API Endpoints

- `GET /items`: Retrieve all items
- `POST /items`: Create a new item
- `GET /items/{id}`: Retrieve an item by ID
- `PUT /items/{id}`: Update an item
- `DELETE /items/{id}`: Delete an item
