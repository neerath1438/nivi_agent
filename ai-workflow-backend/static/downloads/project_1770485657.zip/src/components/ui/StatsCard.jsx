import React from 'react';
import Card from './Card';

const StatsCard = () => {
  return (
    <div className="grid grid-cols-4 gap-4">
      <Card>Total Users</Card>
      <Card>Total Revenue</Card>
      <Card>Active Sessions</Card>
      <Card>New Signups</Card>
    </div>
  );
};

export default StatsCard;