import React from 'react';

export const Card = ({ data, styling }) => {
  return (
    <div className={`bg-white bg-opacity-30 backdrop-blur-lg shadow-lg p-4 rounded-lg ${styling}`}> 
      <h3 className="font-semibold">{data.title}</h3>
      <p>{data.value}</p>
    </div>
  );
};