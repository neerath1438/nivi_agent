[
    {
        "file": "main.py",
        "content": "from fastapi import FastAPI\nfrom app.database.database import engine, Base\nfrom app.routes.product_routes import router as product_router\n\n# Initialize FastAPI application\napp = FastAPI()\n\n# Create database tables\nBase.metadata.create_all(bind=engine)\n\n# Include routers\napp.include_router(product_router)"
    },
    {
        "file": "app/models/product.py",
        "content": "from sqlalchemy import Column, Integer, String, Float, DateTime\nfrom sqlalchemy.ext.declarative import declarative_base\nfrom sqlalchemy.sql import func\n\nBase = declarative_base()\n\nclass Product(Base):\n    __tablename__ = 'products'\n    id = Column(Integer, primary_key=True, index=True)\n    name = Column(String, unique=True, nullable=False)\n    description = Column(String, nullable=True)\n    quantity = Column(Integer, nullable=False)\n    price = Column(Float, nullable=False)\n    created_at = Column(DateTime, server_default=func.now())\n    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())"
    },
    {
        "file": "app/schemas/product.py",
        "content": "from pydantic import BaseModel\n\nclass ProductCreate(BaseModel):\n    name: str\n    description: str = None\n    quantity: int\n    price: float\n\nclass ProductRead(ProductCreate):\n    id: int\n    created_at: str\n    updated_at: str\n\nclass ProductUpdate(BaseModel):\n    name: str = None\n    description: str = None\n    quantity: int = None\n    price: float = None"
    },
    {
        "file": "app/database/database.py",
        "content": "from sqlalchemy import create_engine\nfrom sqlalchemy.ext.declarative import declarative_base\nfrom sqlalchemy.orm import sessionmaker\n\nDATABASE_URL = 'sqlite:///:memory:'\n\nengine = create_engine(DATABASE_URL)\nSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)\nBase = declarative_base()"
    },
    {
        "file": "app/services/product_service.py",
        "content": "from sqlalchemy.orm import Session\nfrom app.models.product import Product\nfrom app.schemas.product import ProductCreate, ProductUpdate\n\ndef create_product(db: Session, product: ProductCreate):\n    db_product = Product(**product.dict())\n    db.add(db_product)\n    db.commit()\n    db.refresh(db_product)\n    return db_product\n\ndef get_product(db: Session, product_id: int):\n    return db.query(Product).filter(Product.id == product_id).first()\n\ndef update_product(db: Session, product_id: int, product: ProductUpdate):\n    db_product = db.query(Product).filter(Product.id == product_id).first()\n    for key, value in product.dict(exclude_unset=True).items():\n        setattr(db_product, key, value)\n    db.commit()\n    db.refresh(db_product)\n    return db_product\n\ndef delete_product(db: Session, product_id: int):\n    db_product = db.query(Product).filter(Product.id == product_id).first()\n    db.delete(db_product)\n    db.commit()\n\ndef get_all_products(db: Session):\n    return db.query(Product).all()"
    },
    {
        "file": "app/routes/product_routes.py",
        "content": "from fastapi import APIRouter, Depends, HTTPException\nfrom sqlalchemy.orm import Session\nfrom app.database.database import SessionLocal\nfrom app.schemas.product import ProductCreate, ProductRead, ProductUpdate\nfrom app.services.product_service import create_product, get_product, update_product, delete_product, get_all_products\n\nrouter = APIRouter()\n\n# Dependency to get DB session\ndef get_db():\n    db = SessionLocal()\n    try:\n        yield db\n    finally:\n        db.close()\n\n@router.post('/products', response_model=ProductRead)\ndef create_product_route(product: ProductCreate, db: Session = Depends(get_db)):\n    return create_product(db=db, product=product)\n\n@router.get('/products', response_model=list[ProductRead])\ndef get_all_products_route(db: Session = Depends(get_db)):\n    return get_all_products(db=db)\n\n@router.get('/products/{id}', response_model=ProductRead)\ndef get_product_route(id: int, db: Session = Depends(get_db)):\n    db_product = get_product(db=db, product_id=id)\n    if db_product is None:\n        raise HTTPException(status_code=404, detail='Product not found')\n    return db_product\n\n@router.put('/products/{id}', response_model=ProductRead)\ndef update_product_route(id: int, product: ProductUpdate, db: Session = Depends(get_db)):\n    db_product = update_product(db=db, product_id=id, product=product)\n    if db_product is None:\n        raise HTTPException(status_code=404, detail='Product not found')\n    return db_product\n\n@router.delete('/products/{id}')\ndef delete_product_route(id: int, db: Session = Depends(get_db)):\n    delete_product(db=db, product_id=id)\n    return {'detail': 'Product deleted'}"
    },
    {
        "file": "app/utils/logger.py",
        "content": "import logging\n\n# Setup logging configuration\nlogging.basicConfig(level=logging.INFO,\n                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')\nlogger = logging.getLogger(__name__)\n\n# Example of logging an action\nlogger.info('Logger is set up and ready to log')"
    }
]