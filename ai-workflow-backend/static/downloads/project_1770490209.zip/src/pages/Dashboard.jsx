import React from 'react';
import OverviewCards from '../components/OverviewCards';
import DataTable from '../components/DataTable';

const Dashboard = () => {
  return (
    <div className="flex-1 p-4">
      <OverviewCards />
      <DataTable />
    </div>
  );
};

export default Dashboard;