import React from 'react';

const Sidebar = () => {
  return (
    <aside className="w-64 bg-white shadow-lg h-screen">
      <nav className="p-4">
        <ul>
          <li><a href="#" className="block p-2 hover:bg-gray-200">Home</a></li>
          <li><a href="#" className="block p-2 hover:bg-gray-200">Reports</a></li>
          <li><a href="#" className="block p-2 hover:bg-gray-200">Settings</a></li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;