import React, { useEffect, useState } from 'react';
import Sidebar from './components/Sidebar';
import TopBar from './components/TopBar';
import DashboardCard from './components/DashboardCard';
import { motion } from 'framer-motion';

const App = () => {
  const [metrics, setMetrics] = useState([]);

  useEffect(() => {
    const fetchMetrics = async () => {
      const response = await fetch('/api/metrics');
      const data = await response.json();
      setMetrics(data);
    };
    fetchMetrics();
  }, []);

  return (
    <div className="flex">
      <Sidebar />
      <div className="flex-1">
        <TopBar />
        <motion.main initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="p-4">
          <h1 className="text-2xl font-bold mb-4">Dashboard</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {metrics.map(metric => (
              <DashboardCard key={metric.id} title={metric.title} value={metric.value} />
            ))}
          </div>
        </motion.main>
      </div>
    </div>
  );
};

export default App;