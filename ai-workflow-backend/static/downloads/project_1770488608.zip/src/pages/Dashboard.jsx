import React from 'react';
import { Card } from '../components/ui/Card';
import { Table } from '../components/ui/Table';
import { Timeline } from '../components/ui/Timeline';

export const Dashboard = () => {
  const data = [{ title: 'Revenue', value: '$10,000' }];
  const events = [{ id: 1, date: '2023-10-01', status: 'Order Placed' }];

  return (
    <div>
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
        <Card data={data[0]} styling="h-32" />
        <Table data={[]} searchable={true} filtering={true} />
      </div>
      <Timeline events={events} />
    </div>
  );
};