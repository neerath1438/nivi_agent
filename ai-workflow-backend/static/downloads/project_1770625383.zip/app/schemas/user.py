from pydantic import BaseModel

class UserCreate(BaseModel):
    username: str
    email: str
    password: str

class UserRead(BaseModel):
    id: int
    username: str
    email: str
    created_at: str
    updated_at: str

    class Config:
        orm_mode = True

class UserUpdate(BaseModel):
    username: str = None
    email: str = None
    password: str = None
