import React from 'react';

const HeroSection = () => {
  return (
    <div className="bg-white bg-opacity-30 backdrop-blur-lg shadow-xl p-6 rounded-lg text-center">
      <h1 className="text-3xl font-bold text-white">Total Portfolio Value</h1>
      <p className="text-xl text-gray-300">$10,000</p>
      <select className="mt-4 p-2 rounded bg-gray-200">
        <option>USD</option>
        <option>EUR</option>
      </select>
      <button className="mt-4 bg-primary text-white px-4 py-2 rounded hover:scale-105 transition-all">View Details</button>
    </div>
  );
};

export default HeroSection;