import React from 'react';

const Button = ({ text, onClick, type = 'button', className }) => {
  return (
    <button onClick={onClick} type={type} className={`hover:bg-blue-600 rounded-md p-2 ${className}`}> {text} </button>
  );
};

export default Button;