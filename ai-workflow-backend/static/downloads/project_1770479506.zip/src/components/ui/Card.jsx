import React from 'react';

const Card = ({ image, title, price, description }) => {
    return (
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
            <img src={image} alt={title} className="w-full h-48 object-cover" />
            <div className="p-4">
                <h2 className="text-xl font-semibold">{title}</h2>
                <p className="text-gray-700">{description}</p>
                <p className="text-lg font-bold text-blue-500">${price}</p>
            </div>
        </div>
    );
};

export default Card;