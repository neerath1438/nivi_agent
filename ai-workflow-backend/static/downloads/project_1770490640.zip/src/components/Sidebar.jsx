import React from 'react';

const Sidebar = () => {
  return (
    <aside className="w-64 bg-white bg-opacity-30 backdrop-blur-lg p-4 shadow-md">
      <nav>
        <ul>
          <li>Home</li>
          <li>Reports</li>
          <li>Settings</li>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;