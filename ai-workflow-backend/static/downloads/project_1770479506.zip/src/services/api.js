const API_ENDPOINT = 'path/to/mock/api';

export const fetchProperties = async () => {
    try {
        const response = await fetch(API_ENDPOINT);
        if (!response.ok) throw new Error('Network response was not ok');
        const data = await response.json();
        return data.properties;
    } catch (error) {
        console.error('Failed to fetch properties:', error);
        throw error;
    }
};