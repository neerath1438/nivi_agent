from fastapi import FastAPI
from app.api.v1.api_router import api_router

app = FastAPI(docs_url='/docs', redoc_url='/redoc')

app.include_router(api_router)
