from sqlalchemy import Column, Integer, String, Float
from app.models.base import Base

class FinanceRecord(Base):
    __tablename__ = 'finance_records'
    id = Column(Integer, primary_key=True, index=True)
    date = Column(String, index=True)
    category = Column(String)
    amount = Column(Float)
    description = Column(String, nullable=True)
