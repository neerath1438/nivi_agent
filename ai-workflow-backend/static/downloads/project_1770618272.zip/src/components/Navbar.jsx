import React from 'react';
import { Lucide } from 'lucide-react';

const Navbar = () => {
  return (
    <div className="bg-white bg-opacity-30 backdrop-blur-lg shadow-xl p-4 rounded-lg flex justify-between items-center">
      <div className="text-xl font-bold text-white">Logo</div>
      <div className="relative">
        <button className="text-white hover:underline">Profile</button>
        <Lucide icon="ChevronDown" className="absolute right-0 top-0 mt-1 ml-1" />
      </div>
    </div>
  );
};

export default Navbar;