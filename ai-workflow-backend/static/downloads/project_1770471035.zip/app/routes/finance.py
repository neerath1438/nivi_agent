from fastapi import APIRouter, HTTPException
from app.models.finance import Income, Expense, Budget
from app.schemas.finance import IncomeSchema, ExpenseSchema, BudgetSchema
from app.services.finance import IncomeService, ExpenseService, BudgetService

router = APIRouter()

@router.post("/income", response_model=IncomeSchema)
async def create_income(income: IncomeSchema):
    return IncomeService.create(income)

@router.get("/income")
async def get_incomes():
    return IncomeService.retrieve()

@router.put("/income/{id}")
async def update_income(id: int, income: IncomeSchema):
    return IncomeService.update(id, income)

@router.delete("/income/{id}")
async def delete_income(id: int):
    return IncomeService.delete(id)

@router.post("/expenses", response_model=ExpenseSchema)
async def create_expense(expense: ExpenseSchema):
    return ExpenseService.create(expense)

@router.get("/expenses")
async def get_expenses():
    return ExpenseService.retrieve()

@router.put("/expenses/{id}")
async def update_expense(id: int, expense: ExpenseSchema):
    return ExpenseService.update(id, expense)

@router.delete("/expenses/{id}")
async def delete_expense(id: int):
    return ExpenseService.delete(id)

@router.post("/budget", response_model=BudgetSchema)
async def create_budget(budget: BudgetSchema):
    return BudgetService.create(budget)

@router.get("/budget")
async def get_budgets():
    return BudgetService.retrieve()

@router.put("/budget/{id}")
async def update_budget(id: int, budget: BudgetSchema):
    return BudgetService.update(id, budget)

@router.delete("/budget/{id}")
async def delete_budget(id: int):
    return BudgetService.delete(id)
