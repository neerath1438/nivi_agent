# Configuration settings
DATABASE_URL = "sqlite:///:memory:"
