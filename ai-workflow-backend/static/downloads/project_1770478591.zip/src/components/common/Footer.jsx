import React from 'react';

const Footer = () => {
    return (
        <footer className="bg-gray-200 text-center py-4">
            <p className="text-gray-600">© 2023 Real Estate Portal. All rights reserved.</p>
            <div className="flex justify-center space-x-4">
                <a href="#" className="text-blue-500 hover:underline">Privacy Policy</a>
                <a href="#" className="text-blue-500 hover:underline">Terms of Service</a>
            </div>
        </footer>
    );
};

export default Footer;