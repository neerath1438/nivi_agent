import React from 'react';

const TopBar = () => {
  return (
    <header className="flex justify-between items-center p-4 bg-white shadow-md">
      <h2 className="text-xl font-semibold">Dashboard</h2>
      <div className="flex items-center">
        <button className="p-2 hover:bg-gray-200 rounded-full">
          <span className="material-icons">notifications</span>
        </button>
        <button className="p-2 hover:bg-gray-200 rounded-full">
          <span className="material-icons">account_circle</span>
        </button>
      </div>
    </header>
  );
};

export default TopBar;