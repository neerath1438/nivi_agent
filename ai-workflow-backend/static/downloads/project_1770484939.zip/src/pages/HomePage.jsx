import React from 'react';
import Navbar from '../components/common/Navbar';
import Footer from '../components/common/Footer';

const HomePage = () => {
  return (
    <div>
      <Navbar />
      <h2>Welcome to the Home Page</h2>
      <Footer />
    </div>
  );
};

export default HomePage;