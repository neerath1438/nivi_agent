from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

app = FastAPI()

class UserInput(BaseModel):
    input_data: str

class ProcessedData(Base):
    __tablename__ = "processed_data"
    id = Column(Integer, primary_key=True, index=True)
    input_data = Column(String, index=True)
    result_data = Column(String)

Base.metadata.create_all(bind=engine)

@app.post("/process")
async def process_data(user_input: UserInput):
    try:
        result = process_input(user_input)
        return {"result": result}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

def process_input(user_input: UserInput) -> str:
    # Mock processing logic
    return f"Processed: {user_input.input_data}"