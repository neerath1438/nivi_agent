import React from 'react';

const Reports = () => {
  return (
    <div>
      <h2 className="text-2xl font-bold">Reports</h2>
      <p>Here you can view your reports.</p>
    </div>
  );
};

export default Reports;