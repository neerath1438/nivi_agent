from sqlalchemy.ext.asyncio import AsyncSession
from app.models.product import Product
from app.repositories.product_repo import create_product as repo_create_product, delete_product as repo_delete_product

async def create_product(product_data, db: AsyncSession):
    product = Product(name=product_data.name, description=product_data.description, price=product_data.price)
    return await repo_create_product(db, product)

async def delete_product(product_id: int, db: AsyncSession):
    return await repo_delete_product(db, product_id)
