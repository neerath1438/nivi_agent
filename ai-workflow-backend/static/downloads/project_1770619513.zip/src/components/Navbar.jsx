import React from 'react';
import { LucideIcon } from 'lucide-react';

const Navbar = () => {
  return (
    <div className="flex justify-between items-center p-5 bg-white bg-opacity-30 backdrop-blur-lg shadow-xl">
      <h1 className="text-2xl font-bold text-white">Crypto Dashboard</h1>
      <div className="flex items-center space-x-4">
        <input type="text" placeholder="Search..." className="p-2 rounded bg-gray-200" />
        <LucideIcon name="Bell" className="text-white" />
      </div>
    </div>
  );
};

export default Navbar;