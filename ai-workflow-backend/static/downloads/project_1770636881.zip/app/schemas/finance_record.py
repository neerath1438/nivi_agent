from pydantic import BaseModel

class FinanceRecordBase(BaseModel):
    date: str
    category: str
    amount: float
    description: str | None = None

class FinanceRecordCreate(FinanceRecordBase):
    pass

class FinanceRecordResponse(FinanceRecordBase):
    id: int

    class Config:
        model_config = ConfigDict(from_attributes=True)
