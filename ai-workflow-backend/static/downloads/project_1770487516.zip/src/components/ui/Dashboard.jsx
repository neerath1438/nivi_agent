import React from 'react';
import WidgetA from '../common/WidgetA';
import WidgetB from '../common/WidgetB';
import WidgetC from '../common/WidgetC';

const Dashboard = () => {
  return (
    <main className='p-4 grid grid-cols-3 gap-4'>
      <WidgetA />
      <WidgetB />
      <WidgetC />
    </main>
  );
};

export default Dashboard;