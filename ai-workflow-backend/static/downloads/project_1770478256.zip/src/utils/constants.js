export const APP_NAME = 'Real Estate Portal';
export const API_BASE_URL = 'https://api.example.com';