import React from 'react';

const Footer = () => {
    return (
        <footer className="bg-blue-600 p-4 text-white text-center">
            <p>© 2023 Real Estate Portal</p>
            <p>Follow us on social media</p>
        </footer>
    );
};

export default Footer;