import React from 'react';
import Navbar from '../components/Navbar.jsx';
import Stat3DCard from '../components/Stat3DCard.jsx';
import { BarChart } from 'lucide-react';

const Dashboard = () => {
  return (
    <div className="p-6">
      <Navbar />
      <div className="grid grid-cols-3 gap-4 mt-4">
        <Stat3DCard title="Users" value="1,234" icon={<BarChart />} />
        <Stat3DCard title="Sales" value="$12,345" icon={<BarChart />} />
        <Stat3DCard title="Revenue" value="$67,890" icon={<BarChart />} />
      </div>
    </div>
  );
};

export default Dashboard;