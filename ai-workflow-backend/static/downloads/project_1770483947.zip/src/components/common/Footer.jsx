import React from 'react';

const Footer = () => {
  return (
    <footer className='bg-gray-200 text-center p-4'>
      <p>© 2023 Your Company. All rights reserved.</p>
      <div className='space-x-4'>
        <a href='/privacy'>Privacy Policy</a>
        <a href='/terms'>Terms of Service</a>
      </div>
    </footer>
  );
};

export default Footer;