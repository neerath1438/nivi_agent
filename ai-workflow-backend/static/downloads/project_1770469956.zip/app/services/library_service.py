from typing import List, Optional
from app.models import LibraryItem

class LibraryService:
    def __init__(self):
        self.items = []

    def get_all_items(self) -> List[LibraryItem]:
        return self.items

    def create_item(self, item: LibraryItem) -> LibraryItem:
        self.items.append(item)
        return item

    def get_item(self, id: int) -> Optional[LibraryItem]:
        for item in self.items:
            if item.id == id:
                return item
        return None

    def update_item(self, id: int, item: LibraryItem) -> Optional[LibraryItem]:
        for index, existing_item in enumerate(self.items):
            if existing_item.id == id:
                self.items[index] = item
                return item
        return None

    def delete_item(self, id: int) -> bool:
        for index, item in enumerate(self.items):
            if item.id == id:
                del self.items[index]
                return True
        return False
