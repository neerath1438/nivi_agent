import React from 'react';

export const Table = ({ data, searchable, filtering }) => {
  return (
    <div className="overflow-x-auto bg-white bg-opacity-30 backdrop-blur-lg shadow-lg rounded-lg">
      <table className="min-w-full">
        <thead>
          <tr>
            {}
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.id}>
              {}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};