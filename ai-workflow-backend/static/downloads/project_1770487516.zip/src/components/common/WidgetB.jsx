import React from 'react';

const WidgetB = () => {
  return (
    <div className='bg-white p-4 shadow-lg rounded-lg'>
      <h2>Real-time Data Analytics</h2>
      <p>Charts and analytics data goes here.</p>
    </div>
  );
};

export default WidgetB;