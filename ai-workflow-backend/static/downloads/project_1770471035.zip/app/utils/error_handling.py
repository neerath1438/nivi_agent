from fastapi import Request, FastAPI

async def log_request(request: Request):
    # Log request details
    pass

app = FastAPI()
app.middleware("http")(log_request)
