from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, JSON, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, Session
from pydantic import BaseModel
from datetime import datetime
import jwt
import bcrypt
import os

DATABASE_URL = 'sqlite:///:memory:'

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

app = FastAPI()

# Models
class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    hashed_password = Column(String)

class Flow(Base):
    __tablename__ = 'flows'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users.id'))
    name = Column(String)
    parameters = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    user = relationship('User', back_populates='flows')

User.flows = relationship('Flow', back_populates='user')

Base.metadata.create_all(bind=engine)

# Pydantic Schemas
class UserCreate(BaseModel):
    username: str
    password: str

class UserOut(BaseModel):
    id: int
    username: str

class FlowCreate(BaseModel):
    name: str
    parameters: dict

class FlowOut(BaseModel):
    id: int
    user_id: int
    name: str
    parameters: dict
    created_at: datetime
    updated_at: datetime

# Security
oauth2_scheme = OAuth2PasswordBearer(tokenUrl='login')

def verify_password(plain_password, hashed_password):
    return bcrypt.checkpw(plain_password.encode('utf-8'), hashed_password.encode('utf-8'))

def get_password_hash(password):
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def create_access_token(data: dict):
    return jwt.encode(data, os.getenv('SECRET_KEY', 'secret'), algorithm='HS256')

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# User Authentication
@app.post('/register', response_model=UserOut)
def register(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.username == user.username).first()
    if db_user:
        raise HTTPException(status_code=400, detail='Username already registered')
    hashed_password = get_password_hash(user.password)
    new_user = User(username=user.username, hashed_password=hashed_password)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

@app.post('/login')
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Invalid credentials')
    access_token = create_access_token(data={'sub': user.username})
    return {'access_token': access_token, 'token_type': 'bearer'}

# Flow Management
@app.post('/flows', response_model=FlowOut)
def create_flow(flow: FlowCreate, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    user = db.query(User).filter(User.username == jwt.decode(token, os.getenv('SECRET_KEY', 'secret'), algorithms=['HS256'])['sub']).first()
    new_flow = Flow(user_id=user.id, **flow.dict())
    db.add(new_flow)
    db.commit()
    db.refresh(new_flow)
    return new_flow

@app.get('/flows', response_model=list[FlowOut])
def read_flows(db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    user = db.query(User).filter(User.username == jwt.decode(token, os.getenv('SECRET_KEY', 'secret'), algorithms=['HS256'])['sub']).first()
    return db.query(Flow).filter(Flow.user_id == user.id).all()

@app.put('/flows/{id}', response_model=FlowOut)
def update_flow(id: int, flow: FlowCreate, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    user = db.query(User).filter(User.username == jwt.decode(token, os.getenv('SECRET_KEY', 'secret'), algorithms=['HS256'])['sub']).first()
    db_flow = db.query(Flow).filter(Flow.id == id, Flow.user_id == user.id).first()
    if not db_flow:
        raise HTTPException(status_code=404, detail='Flow not found')
    for key, value in flow.dict().items():
        setattr(db_flow, key, value)
    db.commit()
    db.refresh(db_flow)
    return db_flow

@app.delete('/flows/{id}', status_code=status.HTTP_204_NO_CONTENT)
def delete_flow(id: int, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    user = db.query(User).filter(User.username == jwt.decode(token, os.getenv('SECRET_KEY', 'secret'), algorithms=['HS256'])['sub']).first()
    db_flow = db.query(Flow).filter(Flow.id == id, Flow.user_id == user.id).first()
    if not db_flow:
        raise HTTPException(status_code=404, detail='Flow not found')
    db.delete(db_flow)
    db.commit()

@app.get('/flows/{id}/visualize')
def visualize_flow(id: int, db: Session = Depends(get_db), token: str = Depends(oauth2_scheme)):
    user = db.query(User).filter(User.username == jwt.decode(token, os.getenv('SECRET_KEY', 'secret'), algorithms=['HS256'])['sub']).first()
    db_flow = db.query(Flow).filter(Flow.id == id, Flow.user_id == user.id).first()
    if not db_flow:
        raise HTTPException(status_code=404, detail='Flow not found')
    return {'visualization': db_flow.parameters}