import shutil
import os

shutil.make_archive('library_api', 'zip', os.getcwd())
