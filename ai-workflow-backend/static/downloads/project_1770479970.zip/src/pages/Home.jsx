import React, { useEffect, useState } from 'react';
import { fetchProperties } from '../api/api';

const Home = () => {
    const [properties, setProperties] = useState([]);

    useEffect(() => {
        const getProperties = async () => {
            const data = await fetchProperties();
            setProperties(data);
        };
        getProperties();
    }, []);

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {properties.map(property => (
                <div key={property.id} className="border p-4 rounded-lg">
                    <h2 className="text-lg font-bold">{property.title}</h2>
                    <p>{property.description}</p>
                </div>
            ))}
        </div>
    );
};

export default Home;