import React from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import Footer from './Footer';
import BarChart from './Charts/BarChart';
import LineChart from './Charts/LineChart';
import UserTable from './Tables/UserTable';
import AnalyticsTable from './Tables/AnalyticsTable';

const Dashboard = () => {
  return (
    <div className="flex flex-col flex-1 p-4 bg-white bg-opacity-30 backdrop-blur-lg rounded-lg shadow-lg">
      <Header />
      <div className="flex flex-row">
        <Sidebar />
        <main className="flex-1 p-4">
          <BarChart />
          <LineChart />
          <UserTable />
          <AnalyticsTable />
        </main>
      </div>
      <Footer />
    </div>
  );
};

export default Dashboard;