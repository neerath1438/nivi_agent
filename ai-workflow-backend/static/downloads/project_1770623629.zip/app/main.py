from fastapi import FastAPI
from app.database import engine
from app.models import Base
from app.routes import user_router

Base.metadata.create_all(bind=engine)

app = FastAPI()

app.include_router(user_router, prefix='/users', tags=['users'])