[
  {
    "path": "src/components/ui/Button.jsx",
    "content": "import React from 'react';\n\nconst Button = ({ children, onClick, className }) => {\n  return (\n    <button className={`bg-blue-500 text-white p-2 rounded ${className}`} onClick={onClick}>\n      {children}\n    </button>\n  );\n};\n\nexport default Button;"
  },
  {
    "path": "src/components/ui/Card.jsx",
    "content": "import React from 'react';\n\nconst Card = ({ title, value, icon }) => {\n  return (\n    <div className=\"bg-white shadow-lg rounded-lg p-4\">\n      <div className=\"flex items-center\">\n        <img src={icon} alt={title} className=\"w-6 h-6 mr-2\" />\n        <h3 className=\"text-lg font-semibold\">{title}</h3>\n      </div>\n      <p className=\"text-2xl font-bold\">{value}</p>\n    </div>\n  );\n};\n\nexport default Card;"
  },
  {
    "path": "src/components/ui/Input.jsx",
    "content": "import React from 'react';\n\nconst Input = ({ type, placeholder, value, onChange }) => {\n  return (\n    <input\n      type={type}\n      placeholder={placeholder}\n      value={value}\n      onChange={onChange}\n      className=\"border rounded p-2\"\n    />\n  );\n};\n\nexport default Input;"
  },
  {
    "path": "src/components/common/Navbar.jsx",
    "content": "import React from 'react';\n\nconst Navbar = () => {\n  return (\n    <nav className=\"bg-gray-800 p-4\">\n      <h1 className=\"text-white text-xl\">Admin Dashboard</h1>\n    </nav>\n  );\n};\n\nexport default Navbar;"
  },
  {
    "path": "src/components/common/Footer.jsx",
    "content": "import React from 'react';\n\nconst Footer = () => {\n  return (\n    <footer className=\"bg-gray-800 p-4 text-white text-center\">\n      <p>&copy; 2023 Admin Dashboard</p>\n    </footer>\n  );\n};\n\nexport default Footer;"
  },
  {
    "path": "src/pages/Dashboard.jsx",
    "content": "import React from 'react';\nimport StatsCard from '../components/ui/Card';\nimport DataTable from '../components/ui/DataTable';\n\nconst Dashboard = () => {\n  return (\n    <div className=\"p-4\">\n      <h2 className=\"text-2xl font-bold\">Dashboard</h2>\n      <div className=\"grid grid-cols-3 gap-4 mt-4\">\n        <StatsCard title=\"Users\" value={100} icon=\"/icons/user.svg\" />\n        <StatsCard title=\"Sales\" value={200} icon=\"/icons/sale.svg\" />\n        <StatsCard title=\"Revenue\" value={300} icon=\"/icons/revenue.svg\" />\n      </div>\n      <DataTable data={[]} columns={[]} />\n    </div>\n  );\n};\n\nexport default Dashboard;"
  },
  {
    "path": "src/pages/Settings.jsx",
    "content": "import React from 'react';\n\nconst Settings = () => {\n  return (\n    <div className=\"p-4\">\n      <h2 className=\"text-2xl font-bold\">Settings</h2>\n      {}\n    </div>\n  );\n};\n\nexport default Settings;"
  },
  {
    "path": "src/api/apiService.js",
    "content": "import axios from 'axios';\n\nconst apiService = axios.create({\n  baseURL: 'https:
  },
  {
    "path": "src/App.jsx",
    "content": "import React from 'react';\nimport { BrowserRouter as Router, Routes, Route } from 'react-router-dom';\nimport Navbar from './components/common/Navbar';\nimport Footer from './components/common/Footer';\nimport Dashboard from './pages/Dashboard';\nimport Settings from './pages/Settings';\n\nconst App = () => {\n  return (\n    <Router>\n      <Navbar />\n      <Routes>\n        <Route path=\"/\" element={<Dashboard />} />\n        <Route path=\"/settings\" element={<Settings />} />\n      </Routes>\n      <Footer />\n    </Router>\n  );\n};\n\nexport default App;"
  },
  {
    "path": "src/main.jsx",
    "content": "import React from 'react';\nimport ReactDOM from 'react-dom/client';\nimport App from './App';\nimport './index.css';\n\nReactDOM.createRoot(document.getElementById('root')).render(<App />);"
  },
  {
    "path": "src/index.css",
    "content": "@tailwind base;\n@tailwind components;\n@tailwind utilities;"
  },
  {
    "path": "vite.config.js",
    "content": "import { defineConfig } from 'vite';\nimport react from '@vitejs/plugin-react';\n\nexport default defineConfig({\n  plugins: [react()],\n  server: {\n    port: 3000\n  },\n  build: {\n    outDir: 'dist'\n  }\n});"
  },
  {
    "path": "tailwind.config.js",
    "content": "module.exports = {\n  content: ['./index.html', './src*.{js,jsx,ts,tsx}'],\n  theme: {\n    extend: {}\n  },\n  plugins: []\n};"
  },
  {
    "path": "public/index.html",
    "content": "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"UTF-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <title>Admin Dashboard</title>\n</head>\n<body>\n  <div id=\"root\"></div>\n  <script type=\"module\" src=\"/src/main.jsx\"></script>\n</body>\n</html>"
  },
  {
    "path": "package.json",
    "content": "{\n  \"name\": \"admin-dashboard\",\n  \"version\": \"1.0.0\",\n  \"scripts\": {\n    \"dev\": \"vite\",\n    \"build\": \"vite build\",\n    \"serve\": \"vite preview\"\n  },\n  \"dependencies\": {\n    \"axios\": \"^1.6.0\",\n    \"framer-motion\": \"^11.0.0\",\n    \"lucide-react\": \"^0.447.0\",\n    \"react\": \"^18.2.0\",\n    \"react-dom\": \"^18.2.0\",\n    \"react-router-dom\": \"^6.22.0\"\n  },\n  \"devDependencies\": {\n    \"@vitejs/plugin-react\": \"^4.2.0\",\n    \"vite\": \"^5.0.0\"\n  }\n}"
  }
]