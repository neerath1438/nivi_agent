[
    {
        "file": "main.py",
        "content": "from fastapi import FastAPI\nfrom app.routers import users\n\napp = FastAPI()\n\napp.include_router(users.router)\n"
    },
    {
        "file": "app/routers/users.py",
        "content": "from fastapi import APIRouter, HTTPException\nfrom pydantic import BaseModel, EmailStr\nfrom sqlalchemy.orm import Session\nfrom app.database import get_db\nfrom app.models import User\nfrom app.utils import hash_password, create_jwt_token\n\nrouter = APIRouter()\n\nclass UserCreate(BaseModel):\n    name: str\n    email: EmailStr\n    password: str\n\n@router.post('/signup')\nasync def signup(user: UserCreate, db: Session = next(get_db())):\n    if len(user.password) < 8:\n        raise HTTPException(status_code=400, detail='Password must be at least 8 characters long.')\n    if not any(c.isupper() for c in user.password):\n        raise HTTPException(status_code=400, detail='Password must contain at least one uppercase letter.')\n    if not any(c.islower() for c in user.password):\n        raise HTTPException(status_code=400, detail='Password must contain at least one lowercase letter.')\n    if not any(c.isdigit() for c in user.password):\n        raise HTTPException(status_code=400, detail='Password must contain at least one digit.')\n    if not any(c in '!@#$%^&*()_+' for c in user.password):\n        raise HTTPException(status_code=400, detail='Password must contain at least one special character.')\n    existing_user = db.query(User).filter(User.email == user.email).first()\n    if existing_user:\n        raise HTTPException(status_code=400, detail='Email already registered.')\n    hashed_password = hash_password(user.password)\n    new_user = User(name=user.name, email=user.email, password_hash=hashed_password)\n    db.add(new_user)\n    db.commit()\n    db.refresh(new_user)\n    access_token = create_jwt_token(new_user.email)\n    return {'access_token': access_token, 'token_type': 'bearer'}\n"
    },
    {
        "file": "app/models/user.py",
        "content": "from sqlalchemy import Column, Integer, String\nfrom app.database import Base\n\nclass User(Base):\n    __tablename__ = 'users'\n    id = Column(Integer, primary_key=True, index=True)\n    name = Column(String, index=True)\n    email = Column(String, unique=True, index=True)\n    password_hash = Column(String)\n"
    },
    {
        "file": "app/utils.py",
        "content": "import bcrypt\nimport jwt\nimport datetime\nfrom fastapi import HTTPException\n\nSECRET_KEY = 'your_secret_key'\nALGORITHM = 'HS256'\n\ndef hash_password(password: str) -> str:\n    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')\n\ndef create_jwt_token(email: str) -> str:\n    expiration = datetime.datetime.utcnow() + datetime.timedelta(hours=1)\n    token = jwt.encode({'sub': email, 'exp': expiration}, SECRET_KEY, algorithm=ALGORITHM)\n    return token\n"
    },
    {
        "file": "app/database.py",
        "content": "from sqlalchemy import create_engine\nfrom sqlalchemy.ext.declarative import declarative_base\nfrom sqlalchemy.orm import sessionmaker\n\nSQLALCHEMY_DATABASE_URL = 'sqlite:///:memory:'\n\nengine = create_engine(SQLALCHEMY_DATABASE_URL)\nSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)\nBase = declarative_base()\n\ndef get_db():\n    db = SessionLocal()\n    try:\n        yield db\n    finally:\n        db.close()\n"
    }
]