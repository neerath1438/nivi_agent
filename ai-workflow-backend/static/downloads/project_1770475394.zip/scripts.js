document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Carousel logic placeholder

// Form validation
const form = document.querySelector('.subscription-form');
form.addEventListener('submit', function (e) {
    const emailInput = document.getElementById('email');
    if (!emailInput.value) {
        e.preventDefault();
        alert('Please enter a valid email.');
    }
});
