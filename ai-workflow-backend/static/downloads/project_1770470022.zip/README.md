# API Project

## Setup Instructions

1. Install dependencies: `pip install -r requirements.txt`
2. Run the application: `uvicorn main:app --reload`

## API Usage

- **Create User**: POST /users/
- **Get User**: GET /users/{id}
- **Create Item**: POST /items/
- **Get Item**: GET /items/{id}

## Examples

### Create User
```json
{
  "name": "John Doe"
}
```

### Create Item
```json
{
  "title": "Sample Item",
  "owner_id": 1
}
```
