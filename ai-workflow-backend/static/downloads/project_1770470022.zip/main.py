from fastapi import FastAPI
from routes.resource_routes import router as resource_router

app = FastAPI()

app.include_router(resource_router)

@app.get("/")
def read_root():
    return {"message": "Welcome to the API"}
