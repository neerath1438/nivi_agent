from fastapi import APIRouter, HTTPException
from app.models import LibraryItem
from app.services.library_service import LibraryService

router = APIRouter()
service = LibraryService()

@router.get("/items")
def get_items():
    return service.get_all_items()

@router.post("/items")
def create_item(item: LibraryItem):
    return service.create_item(item)

@router.get("/items/{id}")
def get_item(id: int):
    item = service.get_item(id)
    if item is None:
        raise HTTPException(status_code=404, detail="Item not found")
    return item

@router.put("/items/{id}")
def update_item(id: int, item: LibraryItem):
    updated_item = service.update_item(id, item)
    if updated_item is None:
        raise HTTPException(status_code=404, detail="Item not found")
    return updated_item

@router.delete("/items/{id}")
def delete_item(id: int):
    success = service.delete_item(id)
    if not success:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"message": "Item deleted successfully"}
