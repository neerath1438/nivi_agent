[
    {
        "filename": "main.py",
        "content": "from fastapi import FastAPI, HTTPException\nfrom pydantic import BaseModel\n\napp = FastAPI()\n\nclass Item(BaseModel):\n    id: int\n    name: str\n    description: str = None\n    price: float\n\nitems_db = []\n\n@app.post('/items/', response_model=Item, status_code=201)\nasync def create_item(item: Item):\n    items_db.append(item)\n    return item\n\n@app.get('/items/', response_model=list[Item])\nasync def read_items():\n    return items_db\n\n@app.get('/items/{item_id}', response_model=Item)\nasync def read_item(item_id: int):\n    for item in items_db:\n        if item.id == item_id:\n            return item\n    raise HTTPException(status_code=404, detail='Item not found')\n\n@app.put('/items/{item_id}', response_model=Item)\nasync def update_item(item_id: int, updated_item: Item):\n    for index, item in enumerate(items_db):\n        if item.id == item_id:\n            items_db[index] = updated_item\n            return updated_item\n    raise HTTPException(status_code=404, detail='Item not found')\n\n@app.delete('/items/{item_id}', status_code=204)\nasync def delete_item(item_id: int):\n    for index, item in enumerate(items_db):\n        if item.id == item_id:\n            del items_db[index]\n            return\n    raise HTTPException(status_code=404, detail='Item not found')"
    },
    {
        "filename": "requirements.txt",
        "content": "fastapi\nuvicorn"
    }
]