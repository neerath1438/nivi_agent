import React from 'react';

const OverviewCards = () => {
  return (
    <div className="grid grid-cols-3 gap-4">
      <div className="bg-white bg-opacity-30 backdrop-blur-lg p-4 rounded-lg shadow-lg">
        <h3 className="text-lg font-bold">Total Users</h3>
        <p className="text-2xl">1,234</p>
      </div>
      <div className="bg-white bg-opacity-30 backdrop-blur-lg p-4 rounded-lg shadow-lg">
        <h3 className="text-lg font-bold">Active Sessions</h3>
        <p className="text-2xl">567</p>
      </div>
      <div className="bg-white bg-opacity-30 backdrop-blur-lg p-4 rounded-lg shadow-lg">
        <h3 className="text-lg font-bold">Revenue</h3>
        <p className="text-2xl">$12,345</p>
      </div>
    </div>
  );
};

export default OverviewCards;