import React from 'react';
import { Lucide } from 'lucide-react';

const Sidebar = () => {
  return (
    <div className="w-64 h-full bg-white bg-opacity-30 backdrop-blur-lg shadow-xl p-4 rounded-lg">
      <h2 className="text-xl font-bold text-white">Crypto Dashboard</h2>
      <nav className="mt-4">
        <ul>
          <li className="py-2 hover:bg-opacity-20 hover:bg-white rounded transition-all">
            <Lucide icon="Home" className="inline-block mr-2" /> Dashboard
          </li>
          <li className="py-2 hover:bg-opacity-20 hover:bg-white rounded transition-all">
            <Lucide icon="Settings" className="inline-block mr-2" /> Settings
          </li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;