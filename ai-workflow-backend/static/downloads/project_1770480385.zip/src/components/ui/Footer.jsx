import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-primary p-4 text-center">
      <p>
        <a href="#">Privacy Policy</a> | 
        <a href="#">Terms of Service</a> | 
        <a href="#">Contact</a>
      </p>
      <div>
        <a href="#">Facebook</a>
        <a href="#">Twitter</a>
        <a href="#">LinkedIn</a>
      </div>
    </footer>
  );
};

export default Footer;