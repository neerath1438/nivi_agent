import React from 'react';
import { Lucide } from 'lucide-react';

export const Sidebar = () => {
  return (
    <div className="w-64 bg-white bg-opacity-30 backdrop-blur-lg shadow-lg p-4">
      <h2 className="text-xl font-bold">Dashboard</h2>
      {}
    </div>
  );
};