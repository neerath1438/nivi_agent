import React, { useEffect, useState } from 'react';
import { fetchProperties } from '../services/api';
import Card from '../components/ui/Card';

const Home = () => {
    const [properties, setProperties] = useState([]);

    useEffect(() => {
        const loadProperties = async () => {
            const data = await fetchProperties();
            setProperties(data);
        };
        loadProperties();
    }, []);

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            {properties.map(property => (
                <Card key={property.id} title={property.title} description={property.description} />
            ))}
        </div>
    );
};

export default Home;