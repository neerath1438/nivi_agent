import React from 'react';

const Settings = () => {
  return (
    <div>
      <h2 className="text-2xl font-semibold">Settings Page</h2>
    </div>
  );
};

export default Settings;