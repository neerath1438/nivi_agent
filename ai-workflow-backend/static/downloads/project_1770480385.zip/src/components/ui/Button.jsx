import React from 'react';

const Button = ({ label, onClick, variant }) => {
  const baseStyle = "px-4 py-2 rounded transition duration-300";
  const variantStyle = variant === 'primary' ? 'bg-primary text-white' : 'bg-gray-200 text-black';
  return (
    <button className={`${baseStyle} ${variantStyle}`} onClick={onClick}>
      {label}
    </button>
  );
};

export default Button;