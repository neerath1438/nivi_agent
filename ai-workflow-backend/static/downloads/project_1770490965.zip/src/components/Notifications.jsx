import React from 'react';

const Notifications = () => {
  return (
    <div className="fixed bottom-4 right-4">
      <p>No new notifications</p>
    </div>
  );
};

export default Notifications;