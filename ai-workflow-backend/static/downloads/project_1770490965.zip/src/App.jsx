import React from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MainContent from './components/MainContent';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Notifications from './components/Notifications';
import Home from './pages/Home';
import Settings from './pages/Settings';

const App = () => {
  return (
    <Router>
      <div className="flex flex-col h-screen bg-gray-100">
        <Header />
        <div className="flex flex-1">
          <Sidebar />
          <MainContent />
        </div>
        <Notifications />
      </div>
    </Router>
  );
};

export default App;