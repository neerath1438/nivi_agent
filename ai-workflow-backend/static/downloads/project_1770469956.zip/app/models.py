from pydantic import BaseModel

class LibraryItem(BaseModel):
    id: int
    title: str
    author: str
    published_year: int
