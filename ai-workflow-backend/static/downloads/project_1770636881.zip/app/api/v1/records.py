from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.models.finance_record import FinanceRecord
from app.schemas.finance_record import FinanceRecordCreate, FinanceRecordResponse

router = APIRouter()

finance_records = []

@router.post('/', response_model=FinanceRecordResponse, status_code=201)
async def create_record(record: FinanceRecordCreate):
    new_record = FinanceRecord(**record.dict())
    finance_records.append(new_record)
    return new_record

@router.get('/', response_model=list[FinanceRecordResponse])
async def read_records():
    return finance_records

@router.get('/{record_id}', response_model=FinanceRecordResponse)
async def read_record(record_id: int):
    for record in finance_records:
        if record.id == record_id:
            return record
    raise HTTPException(status_code=404, detail='Record not found')

@router.put('/{record_id}', response_model=FinanceRecordResponse)
async def update_record(record_id: int, updated_record: FinanceRecordCreate):
    for index, record in enumerate(finance_records):
        if record.id == record_id:
            finance_records[index] = FinanceRecord(**updated_record.dict(), id=record_id)
            return finance_records[index]
    raise HTTPException(status_code=404, detail='Record not found')

@router.delete('/{record_id}', status_code=204)
async def delete_record(record_id: int):
    for index, record in enumerate(finance_records):
        if record.id == record_id:
            del finance_records[index]
            return
    raise HTTPException(status_code=404, detail='Record not found')
