[
    {
        "path": "package.json",
        "content": "{\"name\":\"real-estate-portal\",\"version\":\"1.0.0\",\"scripts\":{\"dev\":\"vite\"},\"dependencies\":{\"react\":\"^18.2.0\",\"react-dom\":\"^18.2.0\",\"tailwindcss\":\"^3.0.0\",\"@vitejs/plugin-react\":\"4.2.0\",\"axios\":\"^0.21.1\"},\"devDependencies\":{\"vite\":\"5.0.0\"}}"
    },
    {
        "path": "vite.config.js",
        "content": "import { defineConfig } from 'vite'; import react from '@vitejs/plugin-react'; export default defineConfig({ plugins: [react()] });"
    },
    {
        "path": "index.html",
        "content": "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"><link href=\"https:
    },
    {
        "path": "src/main.jsx",
        "content": "import React from 'react'; import ReactDOM from 'react-dom'; import App from './App'; ReactDOM.render(<App />, document.getElementById('root'));"
    },
    {
        "path": "src/App.jsx",
        "content": "import React from 'react'; const App = () => <h1>Welcome to the Real Estate Portal</h1>; export default App;"
    }
]