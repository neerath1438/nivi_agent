import React, { useEffect, useState } from 'react';
import { getProperties } from '../services/api';

const Home = () => {
    const [properties, setProperties] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchProperties = async () => {
            try {
                const data = await getProperties();
                setProperties(data);
            } catch (err) {
                setError('Failed to fetch properties');
            } finally {
                setLoading(false);
            }
        };

        fetchProperties();
    }, []);

    if (loading) return <div>Loading...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            {properties.map(property => (
                <div key={property.id} className="border rounded-lg p-4 shadow-lg">
                    <h2 className="font-bold text-lg">{property.title}</h2>
                    <p>{property.description}</p>
                </div>
            ))}
        </div>
    );
};

export default Home;