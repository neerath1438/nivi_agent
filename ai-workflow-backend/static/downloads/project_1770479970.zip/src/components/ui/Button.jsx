import React from 'react';

const Button = ({ label, onClick, styleType }) => {
    return (
        <button onClick={onClick} className={`px-4 py-2 rounded ${styleType}`}>{label}</button>
    );
};

export default Button;