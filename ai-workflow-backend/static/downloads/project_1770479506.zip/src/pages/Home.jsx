import React, { useEffect, useState } from 'react';
import Card from '../components/ui/Card';
import { fetchProperties } from '../services/api';

const Home = () => {
    const [properties, setProperties] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadProperties = async () => {
            try {
                const data = await fetchProperties();
                setProperties(data);
            } catch (err) {
                setError('Failed to load properties');
            }
        };
        loadProperties();
    }, []);

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
            {error && <p className="text-red-500">{error}</p>}
            {properties.map(property => (
                <Card key={property.id} {...property} />
            ))}
        </div>
    );
};

export default Home;