import React from 'react';

const WidgetA = () => {
  return (
    <div className='bg-white p-4 shadow-lg rounded-lg'>
      <h2>User Statistics</h2>
      <p>Summary of user statistics goes here.</p>
    </div>
  );
};

export default WidgetA;