import os

class Settings:
    PROJECT_NAME: str = "Bookstore API"
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///:memory:")

settings = Settings()
