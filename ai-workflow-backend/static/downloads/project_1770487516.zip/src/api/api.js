import axios from 'axios';

export const fetchDataForWidgets = async () => {
  try {
    const response = await axios.get('/api/widgets');
    return response.data;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};