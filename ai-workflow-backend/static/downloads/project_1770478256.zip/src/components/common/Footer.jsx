import React from 'react';

const Footer = () => {
    return (
        <footer className="bg-white shadow mt-4">
            <div className="max-w-7xl mx-auto py-4 text-center">
                <p className="text-gray-600">© 2023 Your Company. All rights reserved.</p>
                <div className="flex justify-center space-x-4">
                    <a href="#" className="text-blue-500">Facebook</a>
                    <a href="#" className="text-blue-500">Twitter</a>
                </div>
            </div>
        </footer>
    );
};

export default Footer;