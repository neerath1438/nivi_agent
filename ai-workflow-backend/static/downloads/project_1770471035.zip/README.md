# Personal Finance Tracker

This is a FastAPI application for tracking personal finances including income, expenses, and budgets.
