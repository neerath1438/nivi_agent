# Bookstore API

This is a RESTful API for managing a bookstore using FastAPI and SQLAlchemy.

## Endpoints
- POST /books/ - Create a new book
- GET /books/ - Retrieve all books
- GET /books/{book_id} - Retrieve a specific book
- PUT /books/{book_id} - Update a specific book
- DELETE /books/{book_id} - Delete a specific book
