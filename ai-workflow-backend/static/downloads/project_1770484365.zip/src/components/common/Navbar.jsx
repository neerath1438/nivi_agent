import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-white shadow">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8">
        <div className="flex justify-between">
          <div className="flex space-x-4">
            <Link to="/" className="text-gray-700 hover:text-blue-500">Home</Link>
            <Link to="/about" className="text-gray-700 hover:text-blue-500">About</Link>
            <Link to="/contact" className="text-gray-700 hover:text-blue-500">Contact</Link>
            <Link to="/listings" className="text-gray-700 hover:text-blue-500">Listings</Link>
          </div>
          <div className="relative">
            <button className="text-gray-700 hover:text-blue-500">Profile</button>
            {}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;