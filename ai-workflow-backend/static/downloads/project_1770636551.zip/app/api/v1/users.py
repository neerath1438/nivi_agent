from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.models.user import User
from app.schemas.user import UserResponse
from app.services.user_service import get_user, delete_user

router = APIRouter()

@router.get('/{user_id}', response_model=UserResponse)
async def read_user(user_id: int, db: AsyncSession = Depends(get_db)):
    user = await get_user(user_id, db)
    if not user:
        raise HTTPException(status_code=404, detail='User not found.')
    return user

@router.delete('/{user_id}', status_code=204)
async def remove_user(user_id: int, db: AsyncSession = Depends(get_db)):
    await delete_user(user_id, db)
