import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-white shadow mt-10">
      <div className="max-w-7xl mx-auto px-2 sm:px-6 lg:px-8 py-4">
        <p className="text-center text-gray-600">© 2023 Your Company. All rights reserved.</p>
        <div className="flex justify-center space-x-4">
          <a href="/privacy" className="text-gray-600 hover:text-blue-500">Privacy Policy</a>
          <a href="/terms" className="text-gray-600 hover:text-blue-500">Terms of Service</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;