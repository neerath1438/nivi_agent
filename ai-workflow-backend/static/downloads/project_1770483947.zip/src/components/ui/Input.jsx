import React from 'react';

const Input = ({ placeholder, type = 'text', value, onChange, className }) => {
  return (
    <input
      type={type}
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      className={`border rounded-md p-2 focus:ring focus:ring-blue-500 ${className}`}
    />
  );
};

export default Input;