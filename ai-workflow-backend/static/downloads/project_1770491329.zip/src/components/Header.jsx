import React from 'react';

const Header = () => {
  return (
    <header className="sticky top-0 bg-white shadow-lg p-4">
      <h1 className="text-xl font-bold">Enterprise SaaS Dashboard</h1>
      <nav className="mt-2">
        <a href="#" className="mr-4">Dashboard</a>
        <a href="#">Reports</a>
      </nav>
    </header>
  );
};

export default Header;