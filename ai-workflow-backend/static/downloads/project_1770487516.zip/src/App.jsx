import React from 'react';
import Header from './components/ui/Header';
import Sidebar from './components/ui/Sidebar';
import Dashboard from './components/ui/Dashboard';
import Footer from './components/ui/Footer';

const App = () => {
  return (
    <div className='flex'>
      <Sidebar />
      <div className='flex-1'>
        <Header />
        <Dashboard />
        <Footer />
      </div>
    </div>
  );
};

export default App;