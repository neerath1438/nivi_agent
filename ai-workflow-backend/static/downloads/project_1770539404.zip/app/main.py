from fastapi import FastAPI
from app.routers import books
from app.database import engine, Base

app = FastAPI()

# Create the database tables
Base.metadata.create_all(bind=engine)

app.include_router(books.router)