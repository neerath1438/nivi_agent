import React from 'react';

const Sidebar = () => {
  return (
    <nav className="w-64 bg-white bg-opacity-30 backdrop-blur-lg rounded-lg shadow-lg p-4">
      <h2 className="text-lg font-bold">Sidebar</h2>
      {}
    </nav>
  );
};

export default Sidebar;