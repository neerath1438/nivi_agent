import React, { useEffect, useState } from 'react';
import { getProperties } from '../api/api';

const Home = () => {
  const [properties, setProperties] = useState([]);

  useEffect(() => {
    const fetchProperties = async () => {
      const data = await getProperties();
      setProperties(data);
    };
    fetchProperties();
  }, []);

  return (
    <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4'>
      {properties.map(property => (
        <div key={property.id} className='border rounded-md p-4'>
          <h2 className='font-bold'>{property.title}</h2>
          <p>{property.description}</p>
        </div>
      ))}
    </div>
  );
};

export default Home;