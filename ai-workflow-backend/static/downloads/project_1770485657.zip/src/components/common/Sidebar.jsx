import React from 'react';
import { Home, Users, DollarSign, Settings } from 'lucide-react';
import { Link } from 'react-router-dom';

const Sidebar = () => {
  return (
    <aside className="fixed w-64 h-full bg-white shadow-lg">
      <ul>
        <li><Link to="/dashboard"><Home /> Dashboard</Link></li>
        <li><Link to="/users"><Users /> Users</Link></li>
        <li><Link to="/revenue"><DollarSign /> Revenue</Link></li>
        <li><Link to="/settings"><Settings /> Settings</Link></li>
      </ul>
    </aside>
  );
};

export default Sidebar;