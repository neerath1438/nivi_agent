import React from 'react';
import { LucideIcon } from 'lucide-react';

const Sidebar = () => {
  return (
    <div className="w-64 h-full bg-white bg-opacity-30 backdrop-blur-lg shadow-xl p-5">
      <h2 className="text-xl font-bold text-white">Portfolio</h2>
      <nav className="mt-5">
        <ul>
          <li className="text-gray-200 hover:text-white transition duration-300"><LucideIcon name="Home" /> Dashboard</li>
          <li className="text-gray-200 hover:text-white transition duration-300"><LucideIcon name="Settings" /> Settings</li>
        </ul>
      </nav>
    </div>
  );
};

export default Sidebar;