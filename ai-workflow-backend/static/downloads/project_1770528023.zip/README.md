# Bookstore API

## Description
This is a RESTful API for managing a bookstore.

## Setup
1. Install dependencies: `pip install -r requirements.txt`
2. Run the application: `uvicorn main:app --reload`

## API Endpoints
- POST /books/ - Create a new book
- GET /books/ - Retrieve a list of books
- GET /books/{book_id} - Retrieve a specific book by ID
- PUT /books/{book_id} - Update a specific book by ID
- DELETE /books/{book_id} - Delete a specific book by ID
