import React from 'react';

const Sidebar = () => {
  return (
    <aside className='w-64 bg-white shadow-lg'>
      <ul className='space-y-2'>
        <li><a href='#' className='flex items-center p-2'>Dashboard</a></li>
        <li><a href='#' className='flex items-center p-2'>Settings</a></li>
      </ul>
    </aside>
  );
};

export default Sidebar;